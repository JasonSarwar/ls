So far, the project consists of only a ls.c file. However, I will be adding header files and organizing the project soon. I only have ls working 
without any flags or files, though it is not perfected. I have a basic idea of how I am going to get all of the flags working. Compiling the ls.c 
file will lead to many warnings because I have declared many integers to represent whether or not a flag is on or off, but I have not implemented 
them yet.